package gntp.bbulsora.project.service;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import gntp.bbulsora.project.dao.BoardDAO;
import gntp.bbulsora.project.vo.BoardVO;

@Service("boardService")
public class BoardService {

	@Autowired
	private BoardDAO boardDAO;
	
	//페이징 조회 계산
	public Map<String, Object> listByPage(String _section, String _pageNum) {
		int section = Integer.parseInt((_section == null)? "1" : _section);
		int pageNum = Integer.parseInt((_pageNum == null)? "1" : _pageNum);
		int offsetNum = (section-1)*100+(pageNum-1)*10;
		List<BoardVO> list = boardDAO.selectByPage(offsetNum);
		Map<String, Object> objects = new HashMap<String, Object>();
		objects.put("section", section);
		objects.put("pageNum", pageNum);
		objects.put("total", boardDAO.selectTotalNumber());
		objects.put("list", list);
		return objects;
	}
	
	//파일 업로드
	public boolean insertOne(BoardVO board) throws Exception {
		boolean flag = false;
		String fileName = null;
		String OriginalFileName = null;
		MultipartFile uploadFile = board.getUploadFile();
		if(!uploadFile.isEmpty()) {
			OriginalFileName = uploadFile.getOriginalFilename();
			String ext = FilenameUtils.getExtension(OriginalFileName);
			System.out.println(ext);
			UUID uuid = UUID.randomUUID();
			fileName = uuid+"."+ext;
			uploadFile.transferTo(new File("D:\\test\\"+fileName));
		}
		board.setFilename(OriginalFileName);
		board.setFilepath(fileName);
		flag = boardDAO.insertOne(board);
		return flag;
	}
}
