package gntp.bbulsora.project.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gntp.bbulsora.project.dao.OrderDAO;
import gntp.bbulsora.project.utils.CodeMakingRule;
import gntp.bbulsora.project.vo.MemberVO;
import gntp.bbulsora.project.vo.OrderVO;

@Service("orderService")
public class OrderService {

	@Autowired
	private OrderDAO orderDAO;
	
	// 권한별 조회 데이터 구분
	public Map<String, Object> getListByAccRights(HttpServletRequest request) {	
		MemberVO vo = (MemberVO)request.getSession().getAttribute("user");
		String compCd = vo.getCompCd();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("fromDate",  request.getParameter("fromDate"));
		map.put("toDate",  request.getParameter("toDate"));
		map.put("compCd", compCd);
		List<OrderVO> list;
		if(compCd.equals("ADMIN")) {
			list = orderDAO.selectAll(map);
		}else if(compCd.substring(0, 3).equals("CLI")) {
			list = orderDAO.selectAllByCompCdForCli(map);
		}else {
			list = orderDAO.selectAllByCompCdForSup(map);
		}
		map.put("list", list);
		map.remove("compCd");
		return map;
	} 
	
	// 복수 품목 처리
	public boolean insertMap(Map<String,String> data) {
		boolean flag = true;
		String compCd = data.remove("compCd");
		String orderCd = CodeMakingRule.OrderCode(compCd);
		OrderVO order = new OrderVO();
		order.setCompCd(compCd);
		order.setOrderCd(orderCd);
		Set<String> keySet = data.keySet();
		Iterator<String> keys = keySet.iterator();
		while(keys.hasNext()) {
			String itemCd = keys.next();
			String orderQtt = data.get(itemCd);
			order.setItemCd(itemCd);
			order.setOrderQtt(Integer.parseInt(orderQtt));
			if(!orderDAO.insertOne(order)) {
				flag = false;
			}
		}
		return flag;
	}

	

}
