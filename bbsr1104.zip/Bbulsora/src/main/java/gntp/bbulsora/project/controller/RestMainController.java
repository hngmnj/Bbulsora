package gntp.bbulsora.project.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gntp.bbulsora.project.dao.ItemDAO;
import gntp.bbulsora.project.service.HomeService;
import gntp.bbulsora.project.vo.ItemVO;

@RestController("restMainController")
@RequestMapping("/rest")
public class RestMainController {
	@Autowired
	private HomeService homeService;
	@Autowired
	private ItemDAO itemDAO;
	/*
	 * 주문관련
	 */
	// 대분류 선택시 해당하는 중분류 리턴
	@RequestMapping(value="/searchMiddle.do", method=RequestMethod.GET)
	public List<ItemVO> searchMiddle(@RequestParam("major") String major){
		return itemDAO.selectMiddleByMajor(major);
	}
	
	// 중분류 선택시 해당하는 소분류 리턴
	@RequestMapping(value="/searchMinor.do", method=RequestMethod.GET)
	public List<ItemVO> searchMinor(@RequestParam("middle") String middle){
		return itemDAO.selectMinorByMiddle(middle);
	}
	
	// 조건검색 결과 리턴
	@RequestMapping(value="/searchItem.do", method=RequestMethod.GET)
	public List<ItemVO> searchItem(HttpServletRequest req){
		Map<String,String> data = new HashMap<String, String>();
		data.put("major", req.getParameter("major"));
		data.put("middle", req.getParameter("middle"));
		data.put("minor", req.getParameter("minor"));
		data.put("searchText", req.getParameter("searchText"));
		return itemDAO.selectSearchItem(data);
	}
	
	// 대분류 리스트 리턴
	@RequestMapping(value="/selectItem.do", method=RequestMethod.GET)
	public ItemVO selectItem(@RequestParam("itemCd") String itemCd){
		return itemDAO.selectOne(itemCd);
	}
	
	/*
	 *  계정 관련
	 */
	//아이디 중복체크
	@RequestMapping(value="/idCheck.do", method=RequestMethod.GET)
	public boolean idCheck(@RequestParam("id") String id) {
		boolean flag = false;
		flag = homeService.idCheck(id);
		return flag;
	}
	
	//아이디 찾기
	@RequestMapping(value="/findId.do", method=RequestMethod.GET)
	public String findId(HttpServletRequest req) {
		return homeService.findId(req.getParameter("name"), req.getParameter("compCd"), req.getParameter("phone"));
	}
	
	//비밀번호 찾기
	@RequestMapping(value="/findPwd.do", method=RequestMethod.GET)
	public String findPwd(HttpServletRequest req) {
		String status = "nag";
		System.out.println(req.getParameter("id"));
		if(homeService.findPwd(req.getParameter("id"), req.getParameter("name"), req.getParameter("compName"), req.getParameter("phone"))) {
			status = "pos";
		}
		return status;
	}
	
	//비밀번호 변경
	@RequestMapping(value="/changePwd.do", method=RequestMethod.GET)
	public String changePwd(HttpServletRequest req) {
		String status = "nag";
		if(homeService.changePwd(req.getParameter("id"), req.getParameter("pwd"))) {
			status = "pos";
		}
		return status;
	}
}
