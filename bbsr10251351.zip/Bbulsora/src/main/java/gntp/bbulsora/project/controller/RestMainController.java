package gntp.bbulsora.project.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import gntp.bbulsora.project.service.HomeService;

@RestController("restMainController")
@RequestMapping("/rest")
public class RestMainController {
	@Autowired
	private HomeService homeService;

	//아이디 중복체크
	@RequestMapping(value="/idCheck.do", method=RequestMethod.GET)
	public boolean idCheck(@RequestParam("id") String id) {
		boolean flag = false;
		flag = homeService.idCheck(id);
		return flag;
	}
	
	//아이디 찾기
	@RequestMapping(value="/findId.do", method=RequestMethod.GET)
	public String findId(HttpServletRequest req) {
		return homeService.findId(req.getParameter("name"), req.getParameter("compCd"), req.getParameter("phone"));
	}
	
	//비밀번호 찾기
	@RequestMapping(value="/findPwd.do", method=RequestMethod.GET)
	public String findPwd(HttpServletRequest req) {
		String status = "nag";
		System.out.println(req.getParameter("id"));
		if(homeService.findPwd(req.getParameter("id"), req.getParameter("name"), req.getParameter("compName"), req.getParameter("phone"))) {
			status = "pos";
		}
		return status;
	}
	
	//비밀번호 변경
	@RequestMapping(value="/changePwd.do", method=RequestMethod.GET)
	public String changePwd(HttpServletRequest req) {
		String status = "nag";
		if(homeService.changePwd(req.getParameter("id"), req.getParameter("pwd"))) {
			status = "pos";
		}
		return status;
	}
}
