package gntp.bbulsora.project.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import gntp.bbulsora.project.dao.BoardDAO;
import gntp.bbulsora.project.vo.BoardVO;

@Service("boardService")
public class BoardService {

	@Autowired
	private BoardDAO boardDAO;
	

	//게시판 조건검색
//	private void searchBoardList(Map<String, Object> obj) {
//		List<BoardVO> list = new ArrayList<BoardVO>();
//		String searchText = (String)obj.get("searchText");
//		String searchOption = (String)obj.get("searchOption");
//		
//		if(searchOption.equals("brdWriter")) {
//			obj.put("list", boardDAO.selecByPage());
//			obj.put("total", boardDAO.selectTotalNumber());
//			list = boardDAO.selectWriter(searchText);
//			
//		}else if(searchOption.equals("category")) {
//			list = boardDAO.selectCategory(searchText);
//			
//		}else if(searchOption.equals("title")) {
//			list = boardDAO.selectTitle(searchText);
//			
//		}
//
//	}
	
	//페이징 조회 계산
	public Map<String, Object> listByPage(HttpServletRequest req) {
		Map<String, Object> obj = new HashMap<String, Object>();
		int section = Integer.parseInt((req.getParameter("section") == null)? "1" : req.getParameter("section"));
		int pageNum = Integer.parseInt((req.getParameter("pageNum") == null)? "1" : req.getParameter("pageNum"));
		int offsetNum = (section-1)*100+(pageNum-1)*10;
		String searchText = req.getParameter("searchText");
		String searchOption = req.getParameter("searchOption");
		obj.put("searchOption", searchOption);
		obj.put("searchText", searchText);
		obj.put("section", section);
		obj.put("pageNum", pageNum);
		obj.put("offsetNum", offsetNum);
		boardDAO.selectByPage(obj);
		return obj;
	}
	
	//파일 업로드
	public boolean insertOne(BoardVO board) throws Exception {
		boolean flag = false;
		String fileName = null;
		String OriginalFileName = null;
		MultipartFile uploadFile = board.getUploadFile();
		if(!uploadFile.isEmpty()) {
			OriginalFileName = uploadFile.getOriginalFilename();
			String ext = FilenameUtils.getExtension(OriginalFileName);
			System.out.println(ext);
			UUID uuid = UUID.randomUUID();
			fileName = uuid+"."+ext;
			uploadFile.transferTo(new File("C:\\test\\"+fileName));
		}
		board.setFilename(OriginalFileName);
		board.setFilepath(fileName);
		flag = boardDAO.insertOne(board);
		return flag;
	}
}
