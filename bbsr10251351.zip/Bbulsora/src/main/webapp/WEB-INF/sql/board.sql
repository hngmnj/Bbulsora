use bbsr;

create table board(
brd_seq int primary key auto_increment,
brd_writer varchar(20) not null,
category varchar(20) not null,
title varchar(40) not null,
brd_content varchar(400) not null,
brd_date varchar(20) not null default (curdate()),
filepath varchar(50)
);