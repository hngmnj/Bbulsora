create table state(
	state_cd varchar(20) primary key,
    state_content varchar(20) not null
);
