package gntp.bbulsora.project.vo;

public class CompanyVO {

}
