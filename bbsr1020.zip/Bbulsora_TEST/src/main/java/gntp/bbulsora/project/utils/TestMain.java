package gntp.bbulsora.project.utils;

import java.sql.Timestamp;
import java.util.Date;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		System.out.println(Timestamp.valueOf("2022-01-01 00:00:00"));
	}

}
