package gntp.bbulsora.project.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gntp.bbulsora.project.dao.BoardDAO;
import gntp.bbulsora.project.vo.BoardVO;

@RestController
@RequestMapping("/rest")
public class RestTestCon {

	@Autowired
	private BoardDAO boardDAO;
	
	@RequestMapping(value="/boardList", method=RequestMethod.GET)
	public List<BoardVO> list(HttpServletRequest req) {
		List<BoardVO> list = new ArrayList<BoardVO>();
		System.out.println(req.getParameter("searchOption") + " " + req.getParameter("searchText"));
		if(req.getParameter("searchOption").equals("category")) {
			return boardDAO.selectAll();
		}else {
			return list;
		}
		
	}
}
