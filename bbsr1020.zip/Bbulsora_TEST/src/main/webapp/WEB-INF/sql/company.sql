use bbsr;

drop table company;
create table company(
	comp_cd varchar(20) primary key,
	comp_name varchar(20) not null,
	rep_name varchar(20) not null,
	address varchar(40) not null,
	comp_call varchar(20) not null,
	sort varchar(20) not null
);